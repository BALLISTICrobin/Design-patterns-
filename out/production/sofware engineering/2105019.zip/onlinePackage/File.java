package onlinePackage;

public interface File {
    void setName(String name);
    String getName();
}
