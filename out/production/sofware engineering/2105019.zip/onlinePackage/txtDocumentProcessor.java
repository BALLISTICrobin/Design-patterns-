package onlinePackage;

public class txtDocumentProcessor implements DocumentProcessor {
    private File file;

    public txtDocumentProcessor(File file){
        this.file = file;
    }
    public void LoadDocument(){
        System.out.println("text document is loaded");
    }
    public void SaveDocument(){
        System.out.println("text document is saved");
    }
}
