package onlinePackage;

public interface DocumentProcessor {
    void LoadDocument();
    void SaveDocument();

}
