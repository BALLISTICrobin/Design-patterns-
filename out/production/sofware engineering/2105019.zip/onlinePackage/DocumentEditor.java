package onlinePackage;
import java.util.*;

public class DocumentEditor {
    public static void main(String[] args) {
        String filename=null;
        DocumentProcessor docProcessor = null;
        File file = null;
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter file name");
        filename = scanner.nextLine();
        StringTokenizer token = new StringTokenizer(filename,".");
        while (token.hasMoreTokens()){
            switch (token.nextToken()){

                case "docx":
                    docProcessor = new docxDocumentProcessor();
                    break;

                case "pdf":
                    docProcessor = new pdfDocumentProcessor();
                    break;

                case "txt":
                    docProcessor = new txtDocumentProcessor();
                    break;
            }
        }

    }
}
