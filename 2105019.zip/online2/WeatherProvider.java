package online2;

public interface WeatherProvider {
    String fetchWeather();
}
