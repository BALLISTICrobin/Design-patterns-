package online2;

public class LegacyWeatherService {

    public String getWeatherData() {
        return "Legacy weather data";
    }

}
